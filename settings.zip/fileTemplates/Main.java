package ${PACKAGE_NAME};

import android.app.Activity;
import android.os.Bundle;

/**
 * 
 * @author yuansui
 */
public class ${NAME} extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        
    }
}
